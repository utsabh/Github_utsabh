#include "types.h"
#include "user.h"
#include "fcntl.h"
#include "pstat.h"

unsigned int rand=1;
void spin()
{
  rand = (unsigned)(rand * 1103515245 + 12345);
  rand=rand%10;
  sleep(rand);
}

void print(struct pstat *p)
{
  for(int i=3;i<NPROC;i++)
    {
      if(p->inuse[i]==1)
	printf(1,"\nPid:%d  Tickets:%d  Ticks:%d  Uptime:%d\n",p->pid[i],p->tickets[i],p->ticks[i],uptime());
    }
}

int
main(int argc, char *argv[])
{
  struct pstat p;
  settickets(100);
  int pid;
  for (int kid = 3; kid >0; --kid) {
    pid = fork();
    rand = (unsigned)(rand * 1103515245 + 12345);
    rand=rand%10;
    if(pid < 0){
      printf(1,"Process does not exist\n");
      exit();
    }
    else if(pid==0){
      settickets(10*kid);
      //      spin();
      break;
    }
  }
  spin();
  for (int kid = 3; kid >0; --kid)
    {
      wait();
    }
  getpinfo(&p);
  print(&p);
  exit();
}
