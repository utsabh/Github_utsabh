#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(int argc, char *argv[])
{
  int crt=1;
  if(argv[1]==NULL)
    {
      printf("my-zip: file1 [file2 ...]\n");
      exit(1);
    }
  while(argv[crt]!=NULL)
    {
      FILE *fp= fopen(argv[crt], "r");
      if(fp==NULL)
        {
          printf("my-zip: cannot open file\n");
          exit(1);
        }
      int c=1;
      char buffer;
      char q=fgetc(fp);
 do {
      buffer=fgetc(fp);
      if(buffer==q)
	{
        c++;
	}
      else
        {
          fwrite(&c,sizeof(int),1,stdout);
          fwrite(&q,sizeof(char),1,stdout);
          q=buffer;
          c=1;
        }
 }while(!feof(fp));

 crt++;
 fclose(fp);
    }
  return 0;
}
