#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(int argc, char *argv[])
{
  int c=1;
  if(argv[1]==NULL)
    {
      printf("my-unzip: file1 [file2 ...]\n");
      exit(1);
    }
  while(argv[c]!=NULL)
    {
      FILE *fp= fopen(argv[c], "r");
      if(fp==NULL)
        {
          printf("my-unzip: cannot open file\n");
          exit(1);
        }
      int p;
      char buffer;
      while(!feof(fp))
    {
      size_t r=fread(&p,sizeof(int),1,fp);
      fread(&buffer,1,1,fp);
      for(size_t i=0; i<r; i++)
	{  int j=0;
	  while(j<p)
	    {
	      printf("%c", buffer);
	      j++;
	    }
	}
    }
      c++;
      fclose(fp);
    }
  return 0;
}
