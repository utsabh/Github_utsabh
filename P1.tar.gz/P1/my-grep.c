#include<stdlib.h>
#include<stdio.h>
#include<string.h>
int main(int argc, char *argv[])
{
  int count =2;
  char *c=argv[1];

  if(c==NULL)
    {
      printf("my-grep: searchterm [file ...]\n");
      exit(1);
    }

  if(argv[2]==NULL)
    {
      char buffer[1024];
      while(fgets(buffer, 1024, stdin))
	{       char *q=buffer;
	  while(*q!= '\0')
	    {
	      if(*q==c[0])
		{
		  char *r=q;
		  char *p=c;
		  int f=0;
		  do{
		    if(*p!=*q)
		      {
			f=1;
			break;
		      }
		    p++;
		    q++;
		  }while(*p!='\0');
		  if(f==0)
		    {
		      printf("%s",buffer);
		      break;
		    }
		  q=r;
		}
	      q++;
	    }

	}
    }
  while(argv[count]!=NULL)
    {
      FILE *fp=fopen(argv[count],"r");
      if(fp==NULL)
	{
	  printf("my-grep: cannot open file\n");
	  exit(1);
	}
      size_t p_size=20;
      char *ptr=malloc(p_size * sizeof(char));
      while(getline(&ptr, &p_size, fp)!=-1)
	{
	  char *q=ptr;
	  while(*q!= '\0')
	    {
	      if(*q==c[0])
		{
		  char *r=q;
		  char *p=c;
		  int f=0;
		  do{
		    if(*p!=*q)
		      {
			f=1;
			break;
		      }
		    p++;
		    q++;
		  }while(*p!='\0');
		  if(f==0)
		    {
		      printf("%s",ptr);
		      break;
		    }
		  q=r;
		}
	  q++;
	}
    }
  count++;
  fclose(fp);
  free(ptr);
}
return 0;
}
