#include<stdlib.h>
#include<stdio.h>

int main(int argc, char *argv[]){
  int count =1;
  while(argv[count]!=NULL)
    {
      FILE *fp = fopen(argv[count],"r");
      if(fp==NULL){
	printf("my-cat: cannot open file\n");
	exit(1);
      }

      char buffer[512];
      while(fgets(buffer, 512, fp)!=NULL)
	printf("%s",buffer);

      fclose(fp);
      count++;
    }
  return 0;
}
