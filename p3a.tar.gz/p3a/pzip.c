#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/sysinfo.h>
#include <pthread.h>
#define max 15

int size = 0;
int fptr=0;
int out1 = 0;
int fno;
int x=0;
int chnk = 10485760;
int *fchunk;
int *countsize;

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t empty = PTHREAD_COND_INITIALIZER;
pthread_cond_t fill = PTHREAD_COND_INITIALIZER;

struct zipping
{
  char *cptr;
  int cno;
  int csize;
  int filno;
}queue[max];

struct zipc
{
  int *count;
  char *character;
  int size;
}*out;

void pushq(struct zipping t)
{
  queue[fptr] = t;
  fptr = (fptr + 1) % max;
  size++;
}

struct zipping popq()
{
  struct zipping t = queue[out1];
  out1 = (out1 + 1) % max;
  size--;
  return t;
}

struct zipc compress(char *s, int len)
{
  int i,j=0,count1=0;
  char c;
 struct zipc comp;

 comp.count=malloc(len*sizeof(int));
 comp.character=malloc(len*sizeof(char));
        for(i=0;i<len;i++)
        {
            c=s[i];
            count1=1;
            while(i+1<len && s[i]==s[i+1])
            {
                count1++;
                i++;
            }
        comp.count[j]=count1;
 comp.character[j]=c;
 j++;
    }
 comp.size=j;

 return comp;
 }

void *consumer(void *arg)
{
  while(1)
  {
    pthread_mutex_lock(&lock);
    while(size==0 && x != 1)
    {
      pthread_cond_wait(&fill,&lock);
    }
    if(size==0)
    {
    if(x==1)
    {
              pthread_mutex_unlock(&lock);
              pthread_exit(NULL);
    }
    }
    int val=0;
    struct zipping chunk1;
    chunk1 = popq();
    pthread_cond_signal(&empty);

    pthread_mutex_unlock(&lock);
    struct zipc zchunk = compress(chunk1.cptr,chunk1.csize);
    for(int i=0;i<chunk1.filno;i++)
    {
      val+=fchunk[i];
    }
    pthread_mutex_lock(&lock);

    out[val+chunk1.cno]=zchunk;
    pthread_mutex_unlock(&lock);
  }
  return NULL;
}

void *producer(void *files)
{
  char **arg=(char **)files;
  for(int i=0;i<fno;i++)
  {
    pthread_mutex_lock(&lock);
    int chunks=fchunk[i];
    pthread_mutex_unlock(&lock);
    int fp=open(arg[i],O_RDONLY);
    if(fp<0)
    {
      printf("pzip:cannot open file\n");
      exit(1);
    }
    struct stat filestat;
    int filesize;

    if(stat(arg[i],&filestat)==0)
    {
      filesize = (int)filestat.st_size;
    }
    else
    {   
              return NULL;
    }
    char *reads=mmap(NULL, filesize , PROT_READ, MAP_SHARED, fp, 0);
    char *t=reads;
    for(int j = 0; j < chunks; j++)
    {
      pthread_mutex_lock(&lock);
      while(size==max)
    {
            pthread_cond_wait(&empty,&lock);
    }
      pthread_mutex_unlock(&lock);
      struct zipping chunk1;
      if(j==chunks-1)
      {
        chunk1.cptr=(char*)malloc(countsize[i]*sizeof(char));
        chunk1.csize=countsize[i];
      }
      else
      {
        chunk1.cptr=(char*)malloc(chnk*sizeof(char));
        chunk1.csize=chnk;
      }
      chunk1.cptr=t;
      chunk1.cno=j;
      chunk1.filno=i;
      t+=chnk;

      pthread_mutex_lock(&lock);
      pushq(chunk1);
      pthread_cond_signal(&fill);
      pthread_mutex_unlock(&lock);
    }
    close(fp);
  }
  pthread_mutex_lock(&lock);
  x=1;
  pthread_cond_broadcast(&fill);
  pthread_mutex_unlock(&lock);
  return NULL;
}

int main(int argc, char *argv[])
{ 

  if(argv[1]==NULL)
  {
    printf("pzip: file1 [file2...]\n");
    exit(1);
  }

  fno=argc-1;
  int out_size=0;
  int pno=get_nprocs();
  fchunk=(int*)malloc(fno*sizeof(int));
  countsize=(int*)malloc(fno*sizeof(int));
  pthread_t prod;
  pthread_t cons[pno];

  for(int i=0;i<argc-1;i++)
  {
    struct stat filestat;int filesize;
    if(stat(argv[i+1],&filestat)==0)
    {
      filesize =(int)filestat.st_size;
    }
    else
      filesize=-1;
    if(filesize % chnk == 0)
    {
      fchunk[i]=filesize/chnk;
      countsize[i]=chnk;
      out_size+=fchunk[i];
    }
    else
    {
      fchunk[i]=(filesize/chnk)+1;
      countsize[i]=filesize % chnk;
      out_size+=fchunk[i];
    }
  out=malloc(out_size*sizeof(struct zipc));
  }
  pthread_create(&prod, NULL, producer, (argv+1));
  for (int i = 0; i < pno; i++)
  {
    pthread_create(&cons[i], NULL, consumer, NULL);
    pthread_join(prod, NULL);
  }
  for (int i = 0; i < pno; i++)
  {
    pthread_join(cons[i], NULL);
  }
  for(int i=0;i<out_size-1;i++)
  {
    if(out[i].character[out[i].size-1]==out[i+1].character[0])
    {
      out[i+1].count[0]+=out[i].count[out[i].size-1];
      out[i].size--;
    }
  }
  char *buffer=malloc(out_size*chnk*(sizeof(int)+sizeof(char)));
  char *t=buffer;
  for(int i=0;i<out_size;i++)
  {
    for(int j=0;j<out[i].size;j++)
    {
      *((int*)buffer)=out[i].count[j];
      buffer+=sizeof(int);
      *buffer=out[i].character[j];
      buffer+=sizeof(char);
    }

}
  fwrite(t,buffer-t,1,stdout);
  return 0; 
}

